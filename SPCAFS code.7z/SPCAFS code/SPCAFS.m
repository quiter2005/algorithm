function [id,obj,W] = SPCAFS(X,gamma,m)
% Input
% X: dim*num data matrix
% gamma: regularization parameter
% m: projection dimension of W (dim*m)

%Output
%id: sorted features by ||w_i||_2

% Ref: Sparse PCA via L2,p-Norm Regularization for Unsupervised Feature Selection, 2021. 
% Authors: Zhengxin Li, Feiping Nie, Jintang Bian, Danyang Wu, and Xuelong Li.

num = size(X,2);
dim = size(X,1);

% W
[W,obj] = InterationW_SPCA(X,gamma,m);

sqW = (W.^2);
sumW = sum(sqW,2);
[~,id] = sort(sumW,'descend');

end




